# SmartAgri Control Center — frontend starter

A responsive React + Vite dashboard prototype for an Arduino smart-agriculture project with smart irrigation, smart streetlights, and a smart dustbin.

## What's included
- Overview dashboard with KPI cards, charts, module status and recent activity
- Irrigation page with moisture chart, demo pump control, automatic-mode toggle and threshold slider
- Streetlight monitoring page with activity chart and automatic-mode toggle
- Smart dustbin page with fill level and collection alert UI
- Analytics & reports page with charts and CSV export
- Activity & alerts page
- Devices & connection page for Arduino UNO + HC-05 setup
- Responsive layout for desktop, tablet and mobile

## Run locally
Requires Node.js 20+ recommended.

```bash
npm install
npm run dev
```

Open the local URL Vite prints, usually http://localhost:5173.

## Important: demo data and hardware connection
This frontend currently uses illustrative demo data. The pump/light toggles update UI state only; they do not send commands to the Arduino. The CSV is an example export, not a database dump. No MongoDB or Bluetooth connection is configured yet.

HC-05 uses Bluetooth Classic serial. Standard browser Web Bluetooth support generally does not provide the Bluetooth Classic serial profile required by HC-05. Recommended next step is a small local Node.js bridge on the computer paired to the HC-05. The bridge can read serial messages and expose updates to this React UI over WebSocket or HTTP. First inspect the existing Arduino sketch's Serial output and command format so the bridge can match it without unnecessarily changing working hardware code.

## Suggested next steps
1. Confirm Arduino sketch serial output and baud rate.
2. Pair HC-05 with the laptop and identify its serial/COM port.
3. Implement and test a local Node.js serial bridge.
4. Define a stable message format (prefer newline-delimited JSON if the sketch can be adjusted safely).
5. Save readings/events through an Express API to MongoDB.
6. Replace demo values with live bridge events and database history.
7. Gate all remote-control buttons behind a verified connection and confirmed command protocol.

## Stack
- React + Vite
- Recharts
- Lucide React icons
- Custom CSS responsive design (easy to move to Tailwind later)
